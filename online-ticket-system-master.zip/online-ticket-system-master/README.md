# OTiS (Online Ticket System)
An online ticket system that creates and validates digital tickets through QR codes.
